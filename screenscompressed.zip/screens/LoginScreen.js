// screens/LoginScreen.js
import React, { useState,useContext } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';
import { UserContext } from './UserContext';
const LoginScreen = ({ navigation }) => {
  const [name, setName] = useState('');
  const [email, setEmail]=useState('')
  const [password, setPassword] = useState('');
  const { login } = useContext(UserContext);


  

  const handleLogin = () => {
    const success = login(email, password);
    if (success) {
      navigation.navigate('Dashboard');
    } else {
      Alert.alert('Invalid credentials');
    }
  };


  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Login</Text>
      <TextInput
        style={styles.input}
        placeholder="Username"
        autoCapitalize="none"
        value={email}
        onChangeText={setEmail}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <Button title="Login" onPress={handleLogin} />

        <View style={{ marginTop: 20 }}>
  <Text style={{ textAlign: 'center' }}>
    Don't have an account?{' '}
    <Text
      style={{ color: 'blue' }}
      onPress={() => navigation.navigate('Register')}
    >
      Register here
    </Text>
  </Text>
</View>



    </View>
   
  );
};

export default LoginScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 24,
    backgroundColor: '#fff',
  },
  heading: {
    fontSize: 28,
    marginBottom: 24,
    textAlign: 'center',
    fontWeight: 'bold',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 12,
    marginBottom: 16,
    borderRadius: 6,
  },
});
